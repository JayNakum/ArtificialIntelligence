import os
import cv2
import json

def load_images_from_folder(folder:str) -> dict:
    images = {}
    for filename in os.listdir(folder):
        print('reading:', filename)
        img = cv2.imread(os.path.join(folder,filename))
        if img is not None:
            images[filename] = img
    return images

def seperate_images(images:dict, masks:dict) -> None:
    for img_name in images.keys():
        for mask_img in masks.values():
            if (mask_img['filename'] == img_name):
                if (mask_img['regions']):
                    print('with_solar:', img_name)
                    cv2.imwrite('./data/with_solar/' + img_name, images[img_name])
                else:
                    print('without_solar:', img_name)
                    cv2.imwrite('./data/without_solar/' + img_name, images[img_name])

if __name__ == '__main__':
    images = load_images_from_folder('./data_new')
    mask_file = open('./json/masks.json')
    masks = json.load(mask_file)

    seperate_images(images, masks)
