import cv2
import numpy as np
import os
import json

def generate_masks(masks:dict) -> dict:
    mask_images = {}
    for i in masks.keys():
        mask = np.zeros((512, 512), dtype="uint8")
        if (masks[i]['regions']):
            for region in masks[i]['regions']:
                x = region['shape_attributes']['x']
                y = region['shape_attributes']['y']
                width = region['shape_attributes']['width']
                height = region['shape_attributes']['height']
                cv2.rectangle(mask, (x, y), (x + width, y + height), color=(255, 255, 255), thickness=-1)
        print('mask:', masks[i]['filename'])
        mask_images[masks[i]['filename']] = mask
    return mask_images

def verify_masks(data_dir:str, masks_dir:str) -> None:
    data = os.listdir(data_dir)
    masks = os.listdir(masks_dir)

    missing = [x for x in data + masks if x not in data or x not in masks]
    
    if (missing):
        print(missing)

if __name__ == '__main__':
    # mask_file = open('./json/masks.json')

    # masks = json.load(mask_file)
    # mask_images = generate_masks(masks)
    
    # for img_name in mask_images.keys():
    #     cv2.imwrite('../dataset/masks/' + img_name, mask_images[img_name])

    verify_masks('/mnt/c/dev/Solar Panel Detection/dataset/data', '/mnt/c/dev/Solar Panel Detection/dataset/masks')

    # cv2.waitKey()
    # cv2.destroyAllWindows()